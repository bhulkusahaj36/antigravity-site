// ============================================================
// FEED PAGE — Tabs + Conditional fields + Browse logic
// ============================================================

// Load albums into select from static ARTICLES and API initially
async function initAlbumDropdown() {
    const select = document.getElementById('add-album');
    if (!select) return;
    
    let articlesList = [];
    if (typeof ARTICLES !== 'undefined') {
        articlesList = [...ARTICLES];
    }

    // Default static fetch for any newly created articles pending static build
    try {
        const res = await fetch('/api/articles?t=' + Date.now());
        if (res.ok) {
            const dynamic = await res.json();
            articlesList = [...articlesList, ...dynamic];
        }
    } catch(e) {
        console.error("Error fetching albums:", e);
    }
    
    // Clear existing options but keep 'Select' and 'New'
    const staticOptions = Array.from(select.querySelectorAll('option[value=""], option[value="new"]'));
    select.innerHTML = '';
    staticOptions.forEach(opt => select.appendChild(opt));

    const albums = new Set();
    articlesList.forEach(a => {
        if (a.type === 'paravani' && a.album) albums.add(a.album.trim());
    });
    
    const sortedAlbums = Array.from(albums).sort();
    sortedAlbums.forEach(al => {
        // Prevent empty or duplicate built in tags
        if (al !== 'new' && al !== '') {
            const opt = document.createElement('option');
            opt.value = al;
            opt.textContent = al;
            // Insert before the 'new' option
            select.insertBefore(opt, select.querySelector('option[value="new"]'));
        }
    });

    // Rebuild Custom Select UI if it was already built
    if (select._csWrapper) {
        select._csWrapper.remove();
        delete select._csWrapper;
        select.classList.remove('cs-hidden');
    }
    if (typeof window.buildCustomSelect === 'function') {
        window.buildCustomSelect(select);
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    initNav();
    await initAlbumDropdown();

    let quill;

    // Initialize Quill Rich Text Editor IMMEDIATELY if container exists
    if (document.getElementById('editor-container') && typeof Quill !== 'undefined') {
        quill = new Quill('#editor-container', {
            theme: 'snow',
            placeholder: 'અહીં પ્રસંગ લખો (બુલેટ પોઈન્ટ, બોલ્ડ, વગેરેનો ઉપયોગ કરી શકો છો)...',
            modules: {
                toolbar: [
                    [{ 'header': [1, 2, 3, false] }],
                    ['bold', 'italic', 'underline', 'strike'],
                    [{ 'color': [] }, { 'background': [] }],
                    ['blockquote', 'code-block'],
                    [{ 'list': 'ordered' }, { 'list': 'bullet' }],
                    [{ 'align': [] }],
                    ['link', 'image'],
                    ['clean']
                ]
            }
        });
    }

    // Attach listeners for type radio toggles
    const addTypeSelect = document.getElementById('add-type');
    if (addTypeSelect) {
        addTypeSelect.addEventListener('change', (e) => {
            const albumContainer = document.getElementById('album-field-container');
            const prasangOfContainer = document.getElementById('prasang-of-container');
            const authorContainer = document.getElementById('author-field-container');

            if (e.target.value === 'paravani') {
                if (albumContainer) {
                    albumContainer.style.display = 'block';
                    document.getElementById('add-album').required = true;
                }
                if (prasangOfContainer) prasangOfContainer.style.display = 'none';
                if (authorContainer) authorContainer.style.display = 'none';
            } else {
                if (albumContainer) {
                    albumContainer.style.display = 'none';
                    document.getElementById('add-album').required = false;
                }
                if (prasangOfContainer) prasangOfContainer.style.display = 'block';
                if (authorContainer) authorContainer.style.display = 'block';
            }
        });
        
        // Trigger immediately to sync UI with default value
        addTypeSelect.dispatchEvent(new Event('change'));
    }

    // ==========================================
    // ADMIN AUTHENTICATION GUARD
    // NOTE: Firebase auth is async — we do NOT block here.
    // The form submit handler itself calls adminHeaders() which
    // awaits a fresh Firebase token, so unauthenticated POSTs
    // are rejected server-side. Edit-mode loading is gated below
    // via onAuthStateChanged to ensure the user is really signed in.
    // ==========================================
    const adminOverlay = document.getElementById('admin-login-overlay');

    wireDateRadio('add');
    wireDateRadio('br');

    // Wire Album conditional
    if (document.getElementById('add-album')) {
        if (typeof wireConditional === 'function') {
            wireConditional(document.getElementById('add-album'));
        }
    }

    /* ── Add Form submit ────────────────────────────────── */
    const addForm = document.getElementById('addForm');
    const addFeedback = document.getElementById('add-feedback');

    /* ── Admin Edit Mode Initialization ──────────────────── */
    let editingArticleId = null;
    const editId = getParam('editId');
    // Gate edit-mode loading on Firebase auth so we always have
    // a valid token before hitting the API.
    if (editId && typeof firebase !== 'undefined') {
        firebase.auth().onAuthStateChanged(user => {
            if (!user) return; // not signed in — login overlay handles this
            editingArticleId = editId;
        const titleEl = document.querySelector('.page-title');
        if (titleEl) titleEl.textContent = 'પ્રસંગ સંપાદિત કરો (Edit)';
        const submitBtn = document.querySelector('#addForm button[type="submit"]');
        if (submitBtn) submitBtn.textContent = 'Save Changes';

        // Fetch the specific article by ID for editing
        fetch(`/api/articles?id=${encodeURIComponent(editId)}&t=` + Date.now())
            .then(res => res.json())
            .then(data => {
                // API may return a single object, an array, or { items }
                let article = null;
                if (Array.isArray(data)) {
                    article = data.find(a => String(a.id) === String(editId));
                } else if (data && data.items) {
                    article = data.items.find(a => String(a.id) === String(editId));
                } else if (data && data.id) {
                    article = data;
                }
                if (article) {
                    document.getElementById('add-title').value = article.title || '';
                    if (document.getElementById('add-author')) {
                        document.getElementById('add-author').value = article.author || '';
                    }
                    if (document.getElementById('add-location')) {
                        document.getElementById('add-location').value = article.location || '';
                    }

                    if (quill) {
                        quill.clipboard.dangerouslyPasteHTML(article.content || '');
                    } else if (document.getElementById('add-content')) {
                        document.getElementById('add-content').value = article.content || '';
                    }

                    // Pre-select multiple dropdowns
                    const setMultiSelect = (id, valuesCsv) => {
                        const sel = document.getElementById(id);
                        if (!sel || !valuesCsv) return;
                        const vals = valuesCsv.split(',');
                        Array.from(sel.options).forEach(opt => {
                            opt.selected = vals.includes(opt.value);
                            // Custom dropdown UI sync trigger

                            const csOpt = opt.closest('.cs-wrapper')?.querySelector(`.cs-option[data-value="${opt.value}"]`);
                            if (csOpt) {
                                csOpt.classList.toggle('cs-selected', opt.selected);
                                csOpt.setAttribute('aria-selected', opt.selected);
                            }
                        });
                        sel.dispatchEvent(new Event('change', { bubbles: true }));
                    };
                    
                    // Helper for single select with custom UI sync
                    const setSingleSelect = (id, value) => {
                        const sel = document.getElementById(id);
                        if (!sel) return;
                        sel.value = value || '';
                        sel.dispatchEvent(new Event('change', { bubbles: true }));
                    };

                    setMultiSelect('add-source', article.source || '');
                    setMultiSelect('add-topic', article.topic || '');
                    setMultiSelect('add-prasang', article.prasang || '');
                    
                    if (document.getElementById('add-public')) {
                        document.getElementById('add-public').value = (article.public === false || article.public === 'no') ? 'no' : 'yes';
                        const pubToggle = document.getElementById('add-public-toggle');
                        if (pubToggle) pubToggle.checked = (document.getElementById('add-public').value === 'yes');
                    }
                    if (document.getElementById('add-featured')) {
                        document.getElementById('add-featured').value = (article.featured === true || article.featured === 'yes') ? 'yes' : 'no';
                        const featToggle = document.getElementById('add-featured-toggle');
                        if (featToggle) featToggle.checked = (document.getElementById('add-featured').value === 'yes');
                    }

                    if (article.type === 'paravani') {
                        if (document.getElementById('add-type')) document.getElementById('add-type').value = 'paravani';
                        if (document.getElementById('album-field-container')) {
                            document.getElementById('album-field-container').style.display = 'block';
                            document.getElementById('add-album').required = true;
                            
                            const albumSelect = document.getElementById('add-album');
                            const albumVal = article.album || '';
                            
                            // Check if this album exists in existing options
                            const exists = Array.from(albumSelect.options).some(o => o.value === albumVal);
                            if (exists && albumVal !== "") {
                                setSingleSelect('add-album', albumVal);
                            } else if (albumVal !== "") {
                                // It was a custom created album
                                setSingleSelect('add-album', 'new');
                                const customInput = document.getElementById('add-album-new-text');
                                if (customInput) {
                                    customInput.value = albumVal;
                                    customInput.dispatchEvent(new Event('input', { bubbles: true }));
                                }
                            }
                        }
                        // Hide fields not used for Paravani
                        if (document.getElementById('prasang-of-container')) document.getElementById('prasang-of-container').style.display = 'none';
                        if (document.getElementById('author-field-container')) document.getElementById('author-field-container').style.display = 'none';
                    } else {
                        if (document.getElementById('add-type')) document.getElementById('add-type').value = 'prasang';
                        if (document.getElementById('album-field-container')) {
                            document.getElementById('album-field-container').style.display = 'none';
                            document.getElementById('add-album').required = false;
                            document.getElementById('add-album').value = '';
                        }
                        // Show fields for Prasang
                        if (document.getElementById('prasang-of-container')) document.getElementById('prasang-of-container').style.display = 'block';
                        if (document.getElementById('prasang-of-container')) document.getElementById('prasang-of-container').style.display = 'block';
                        if (document.getElementById('author-field-container')) document.getElementById('author-field-container').style.display = 'block';
                    }

                    // Add a "Cancel" button to the form actions
                    const formActions = document.querySelector('#addForm .feed-actions');
                    if (formActions && !document.getElementById('editCancelBtn')) {
                        const cancelBtn = document.createElement('button');
                        cancelBtn.id = 'editCancelBtn';
                        cancelBtn.type = 'button';
                        cancelBtn.className = 'btn btn-outline';
                        cancelBtn.style.borderColor = '#ef4444';
                        cancelBtn.style.color = '#ef4444';
                        cancelBtn.textContent = 'Cancel Edit';
                        cancelBtn.onclick = () => {
                            if (confirm('Discard changes and start a new article?')) {
                                window.location.href = window.location.pathname;
                            }
                        };
                        formActions.appendChild(cancelBtn);
                    }
                }
            })
            .catch(err => console.error("Error loading article for editing:", err));
        }); // end onAuthStateChanged
    }

    let forceSave = false;

    if (addForm) {
        addForm.addEventListener('submit', async e => {
            e.preventDefault();

            const submitBtn = document.querySelector('#addForm button[type="submit"]');
            const originalBtnHtml = submitBtn ? (submitBtn.dataset.originalHtml || submitBtn.innerHTML) : 'પ્રસંગ સંગ્રહ કરો';

            if (submitBtn && !submitBtn.dataset.originalHtml) {
                submitBtn.dataset.originalHtml = originalBtnHtml;
            }

            if (submitBtn) {
                if (!document.getElementById('spinKeyframes')) {
                    const style = document.createElement('style');
                    style.id = 'spinKeyframes';
                    style.innerHTML = '@keyframes spin { to { transform: rotate(360deg); } }';
                    document.head.appendChild(style);
                }
                submitBtn.disabled = true;
                submitBtn.innerHTML = 'Saving... <span style="display:inline-block; margin-left:8px; width:14px; height:14px; border:2px solid currentColor; border-right-color:transparent; border-radius:50%; animation:spin 0.75s linear infinite;"></span>';
            }

            const title = document.getElementById('add-title').value.trim();
            let content = '';
            if (quill) {
                content = quill.getText().trim() === '' ? '' : quill.root.innerHTML;
            } else {
                content = document.getElementById('add-content') ? document.getElementById('add-content').value.trim() : '';
            }

            if (!title || !content) {
                showFeedback(addFeedback, 'error', 'શીર્ષક અને સંદેશ ભરવા જરૂરી છે.');
                if (submitBtn) { submitBtn.disabled = false; submitBtn.innerHTML = originalBtnHtml; }
                return;
            }

            // Validate: Prasang Of is required for non-paravani articles
            const currentType = document.getElementById('add-type') ? document.getElementById('add-type').value : 'prasang';
            if (currentType !== 'paravani') {
                const selectedPrasang = Array.from(document.getElementById('add-prasang').selectedOptions).map(o => o.value).filter(v => v);
                if (selectedPrasang.length === 0) {
                    showFeedback(addFeedback, 'error', '"પ્રસંગ કોના છે?" (Prasang Of) ભરવું ફરજિયાત છે.');
                    document.getElementById('prasang-of-container')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    if (submitBtn) { submitBtn.disabled = false; submitBtn.innerHTML = originalBtnHtml; }
                    return;
                }
            }

            // Handle custom dynamic tags if "other" is selected
            let finalSource = Array.from(document.getElementById('add-source').selectedOptions).map(o => o.value).filter(v => v);
            if (finalSource.includes('other')) {
                const otherText = document.getElementById('add-source-other-text')?.value.trim();
                if (otherText) {
                    const slug = otherText;
                    saveCustomTag('source', slug, otherText);
                    finalSource = finalSource.map(v => v === 'other' ? slug : v);
                }
            }

            let finalTopic = Array.from(document.getElementById('add-topic').selectedOptions).map(o => o.value).filter(v => v);
            if (finalTopic.includes('other')) {
                const otherText = document.getElementById('add-topic-other-text')?.value.trim();
                if (otherText) {
                    const slug = otherText;
                    saveCustomTag('topic', slug, otherText);
                    finalTopic = finalTopic.map(v => v === 'other' ? slug : v);
                }
            }

            let finalPrasang = Array.from(document.getElementById('add-prasang').selectedOptions).map(o => o.value).filter(v => v);
            if (finalPrasang.includes('bhakto')) {
                const otherText = document.getElementById('add-prasang-bhakto-text')?.value.trim();
                if (otherText) {
                    const slug = otherText;
                    finalPrasang = finalPrasang.map(v => v === 'bhakto' ? slug : v);
                }
            }

            // Build article object
            const articleType = document.getElementById('add-type') ? document.getElementById('add-type').value : 'prasang';
            let articleAlbum = document.getElementById('add-album') ? document.getElementById('add-album').value : '';
            if (articleAlbum === 'new') {
                articleAlbum = document.getElementById('add-album-new-text')?.value.trim() || '';
            }

            const article = {
                id: editingArticleId || String(Date.now()),
                title,
                content,
                author: document.getElementById('add-author') ? document.getElementById('add-author').value.trim() || 'Unknown' : 'Unknown',
                source: finalSource.join(','),
                topic: finalTopic.join(','),
                prasang: finalPrasang.join(','),
                date: getDateValue('add'),
                location: document.getElementById('add-location') ? document.getElementById('add-location').value.trim() : '',
                featured: document.getElementById('add-featured') ? (document.getElementById('add-featured').value === 'yes') : false,
                category: finalTopic.join(',') || 'bhakti',
                public: window._draftMode ? false : (document.getElementById('add-public') ? (document.getElementById('add-public').value !== 'no') : true),
                status: window._draftMode ? 'draft' : 'published',
                type: articleType,
                album: articleType === 'paravani' ? articleAlbum : ''
            };

            // ---- Duplicate Content Detection ----
            if (!forceSave && !editingArticleId) {
                try {
                    // Clean content: remove HTML tags, lowercase, remove non-alphanumeric
                    const cleanString = (str) => {
                        if (!str) return '';
                        const tempDiv = document.createElement('div');
                        tempDiv.innerHTML = str;
                        const textContent = tempDiv.textContent || tempDiv.innerText || '';
                        return textContent.toLowerCase().replace(/[^a-z0-9\u0A80-\u0AFF]/g, ''); // includes Gujarati unicode range
                    };

                    const newContentClean = cleanString(content);

                    if (newContentClean.length > 0) { // Check if there is any content
                        const articlesResponse = await fetch('/api/articles?t=' + Date.now());
                        if (articlesResponse.ok) {
                            const allArticles = await articlesResponse.json();
                            const duplicate = allArticles.find(a => cleanString(a.content) === newContentClean);

                            if (duplicate) {
                                showFeedback(addFeedback, 'error', `<strong>Warning:</strong> This article's content appears to be a direct duplicate of an existing article titled: "<em>${duplicate.title}</em>". Click the button again to force save.`);
                                if (submitBtn) {
                                    submitBtn.disabled = false;
                                    submitBtn.innerHTML = 'Force Save Duplicate';
                                    submitBtn.style.backgroundColor = 'var(--error)';
                                    submitBtn.style.color = 'white';
                                }
                                forceSave = true; // Next click will bypass this check
                                return; // Stop saving
                            }
                        }
                    }
                } catch (err) {
                    console.warn("Could not check for duplicates:", err);
                    // silently fail the check and proceed to save if API is down
                }
            }
            // -------------------------------------

            // Save to database API
            try {
                const response = await fetch('/api/articles', {
                    method: 'POST',
                    headers: await adminHeaders(),
                    body: JSON.stringify(article)
                });

                if (response.ok) {
                    const msg = window._draftMode ? '✓ Saved as Draft!' : '✓ Article Published Successfully!';
                    showFeedback(addFeedback, 'success', msg);
                    window._draftMode = false;
                    setTimeout(() => {
                        window.location.href = window.location.pathname;
                    }, 1000);
                } else {
                    const errorText = await response.text();
                    
                    if (response.status === 401) {
                        showFeedback(addFeedback, 'error', 'Unauthorized: Please sign in again.');
                    } else {
                        showFeedback(addFeedback, 'error', 'Error saving article: ' + errorText);
                    }                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = originalBtnHtml;
                        submitBtn.style.backgroundColor = '';
                        submitBtn.style.color = '';
                    }
                    forceSave = false;
                }
            } catch (error) {
                console.error("API error:", error);
                showFeedback(addFeedback, 'error', 'Error connecting to the database: ' + error.message);
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalBtnHtml;
                    submitBtn.style.backgroundColor = '';
                    submitBtn.style.color = '';
                }
                forceSave = false;
            }

        });
    }

    /* ── Browse / Filter ────────────────────────────────── */
    const browseBtn = document.getElementById('browseSearchBtn');
    const browseReset = document.getElementById('browseResetBtn');
    const browseGrid = document.getElementById('browseResults');
    const browseEmpty = document.getElementById('browseEmpty');

    function getDateValue(prefix) {
        const type = document.querySelector(`[name="${prefix}-date-type"]:checked`)?.value;
        if (type === 'date') return document.getElementById(`${prefix}-date-val`)?.value || '';
        if (type === 'range') return {
            from: document.getElementById(`${prefix}-date-from`)?.value || '',
            to: document.getElementById(`${prefix}-date-to`)?.value || '',
        };
        return null;
    }

    function renderCards(articles) {
        browseGrid.innerHTML = '';
        browseEmpty.style.display = articles.length ? 'none' : '';
        articles.forEach(a => {
            const card = document.createElement('div');
            card.className = 'article-card card-animate';
            card.innerHTML = `
          <h3 class="card-title">${a.title}</h3>
          <div class="card-footer" style="padding-top: 1rem;">
            <a href="article.html?id=${a.id || ''}" class="readmore-btn">
              <span class="btn-book-wrapper">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 126 75" class="book">
                      <rect stroke-width="3" stroke="var(--gold-500)" rx="7.5" height="70" width="121" y="2.5" x="2.5"></rect>
                      <line stroke-width="3" stroke="var(--gold-500)" y2="75" x2="63.5" x1="63.5"></line>
                      <path stroke-linecap="round" stroke-width="4" stroke="var(--gold-300)" d="M25 20H50"></path>
                      <path stroke-linecap="round" stroke-width="4" stroke="var(--gold-300)" d="M101 20H76"></path>
                      <path stroke-linecap="round" stroke-width="4" stroke="var(--gold-300)" d="M16 30L50 30"></path>
                      <path stroke-linecap="round" stroke-width="4" stroke="var(--gold-300)" d="M110 30L76 30"></path>
                  </svg>
                  <svg xmlns="http://www.w3.org/2000/svg" fill="var(--gold-500)" viewBox="0 0 65 75" class="book-page">
                      <path stroke-linecap="round" stroke-width="4" stroke="var(--gold-200)" d="M40 20H15"></path>
                      <path stroke-linecap="round" stroke-width="4" stroke="var(--gold-200)" d="M49 35H15"></path>
                      <path stroke-linecap="round" stroke-width="4" stroke="var(--gold-200)" d="M49 50H15"></path>
                      <path stroke-width="3" stroke="var(--gold-500)" d="M2.5 2.5H55C59.1421 2.5 62.5 5.85786 62.5 10V65C62.5 69.1421 59.1421 72.5 55 72.5H2.5V2.5Z"></path>
                  </svg>
              </span>
              <span class="text">વાંચો</span>
            </a>
          </div>`;
            browseGrid.appendChild(card);
        });
    }

    async function runFilter() {
        const source = document.getElementById('br-source').value;
        const topic = document.getElementById('br-topic').value;
        const prasang = document.getElementById('br-prasang').value;
        const dateVal = getDateValue('br');

        let articles = [];
        try {
            const res = await fetch('/api/articles?t=' + Date.now());
            if (res.ok) {
                articles = await res.json();
            }
        } catch (error) {
            console.error("Failed to load articles from database:", error);
        }

        // Also include static ARTICLES from data.js if available
        if (typeof ARTICLES !== 'undefined') articles = [...ARTICLES, ...articles];

        // Ensure purely private articles never show on public feed interface
        articles = articles.filter(a => a.public !== false && a.public !== 'no');

        if (source) articles = articles.filter(a => !a.source || a.source === source);
        if (topic) articles = articles.filter(a => !a.topic || a.category === topic || a.topic === topic);
        if (prasang) articles = articles.filter(a => !a.prasang || a.prasang === prasang);

        if (dateVal && typeof dateVal === 'string' && dateVal) {
            articles = articles.filter(a => a.date === dateVal);
        } else if (dateVal && typeof dateVal === 'object' && dateVal.from) {
            articles = articles.filter(a => {
                if (!a.date) return true;
                const d = typeof a.date === 'string' ? a.date : a.date.from;
                return d >= dateVal.from && d <= dateVal.to;
            });
        }

        renderCards(articles);
    }

    if (browseBtn) {
        browseBtn.addEventListener('click', runFilter);
    }

    if (browseReset) {
        browseReset.addEventListener('click', () => {
            document.getElementById('br-source').selectedIndex = 0;
            document.getElementById('br-topic').selectedIndex = 0;
            document.getElementById('br-prasang').selectedIndex = 0;
            document.querySelectorAll('#panel-browse .feed-conditional').forEach(el => { el.style.display = 'none'; });
            document.querySelectorAll('#panel-browse [name="br-date-type"][value="none"]').forEach(r => { r.checked = true; });
            document.getElementById('br-date-single').style.display = 'none';
            document.getElementById('br-date-range').style.display = 'none';
            browseGrid.innerHTML = '';
            browseEmpty.style.display = 'none';
        });
    }

    /* ── Utility ────────────────────────────────────────── */
    function showFeedback(el, type, msg) {
        el.className = 'form-feedback ' + type;
        el.innerHTML = msg;
        el.style.display = 'block';

        // Scroll up to the notification so the user doesn't miss it
        if (type === 'error') {
            window.scrollTo({ top: Math.max(0, el.offsetTop - 100), behavior: 'smooth' });
            setTimeout(() => { el.style.display = 'none'; }, 8000); // give them more time to read errors
        } else {
            setTimeout(() => { el.style.display = 'none'; }, 3000);
        }
    }

});